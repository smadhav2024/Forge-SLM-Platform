import { proxyAuthenticatedGet } from "@/lib/api/proxy-helpers";
import type { ConversationSummary } from "@/types/api";

export async function GET() {
  return proxyAuthenticatedGet<ConversationSummary[]>("/conversations/");
}
