import { PlaygroundShell } from "@/components/dashboard/playground-shell";
import { PlaygroundEmptyState } from "@/components/playground/playground-empty-state";

export default function PlaygroundPage() {
  return (
    <PlaygroundShell>
      <PlaygroundEmptyState />
    </PlaygroundShell>
  );
}
