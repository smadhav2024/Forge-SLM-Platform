import { NextRequest, NextResponse } from "next/server";
import { backendFetch, backendFetchJson, BackendError } from "@/lib/api/backend";
import { getSessionToken } from "@/lib/api/session";

type Params = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, { params }: Params) {
  const { id } = await params;
  const token = await getSessionToken();
  if (!token) return NextResponse.json({ message: "Not authenticated" }, { status: 401 });

  try {
    const data = await backendFetchJson(`/conversations/${id}/documents`, { token });
    return NextResponse.json(data);
  } catch (err) {
    if (err instanceof BackendError)
      return NextResponse.json({ message: err.message }, { status: err.status });
    return NextResponse.json({ message: "Failed to fetch documents" }, { status: 500 });
  }
}

export async function POST(req: NextRequest, { params }: Params) {
  const { id } = await params;
  const token = await getSessionToken();
  if (!token) return NextResponse.json({ message: "Not authenticated" }, { status: 401 });

  // Forward chunk params from the client request URL to the backend
  const url = new URL(req.url);
  const chunkSize = url.searchParams.get("chunk_size") ?? "500";
  const chunkOverlap = url.searchParams.get("chunk_overlap") ?? "50";

  const formData = await req.formData();

  try {
    const upstream = await backendFetch(
      `/conversations/${id}/documents?chunk_size=${chunkSize}&chunk_overlap=${chunkOverlap}`,
      { method: "POST", token, body: formData }
    );
    const data = await upstream.json();
    return NextResponse.json(data, { status: upstream.status });
  } catch (err) {
    if (err instanceof BackendError)
      return NextResponse.json({ message: err.message }, { status: err.status });
    return NextResponse.json({ message: "Upload failed" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  const { id } = await params;
  const token = await getSessionToken();
  if (!token) return NextResponse.json({ message: "Not authenticated" }, { status: 401 });

  try {
    const data = await backendFetchJson(`/conversations/${id}/documents`, {
      method: "DELETE",
      token,
    });
    return NextResponse.json(data);
  } catch (err) {
    if (err instanceof BackendError)
      return NextResponse.json({ message: err.message }, { status: err.status });
    return NextResponse.json({ message: "Failed to clear documents" }, { status: 500 });
  }
}
